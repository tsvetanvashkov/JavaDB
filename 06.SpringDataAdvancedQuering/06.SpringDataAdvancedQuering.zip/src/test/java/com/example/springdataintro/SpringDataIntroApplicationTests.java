package com.example.springdataintro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataIntroApplicationTests {

    @Test
    void contextLoads() {
    }

}
