package com.example.springdataintro.model.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
